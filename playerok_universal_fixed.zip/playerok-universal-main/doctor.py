"""Быстрая диагностика окружения без токенов и сетевых запросов.

Запуск: python doctor.py
"""
from __future__ import annotations
import ast
import sys
from pathlib import Path
from bootstrap import missing_requirements

ROOT = Path(__file__).resolve().parent


def main() -> int:
    print(f"Python: {sys.version.split()[0]} | Исполняемый файл: {sys.executable}")
    if sys.version_info[:2] != (3, 12):
        print("[Внимание] Проект рассчитан на Python 3.12.x")
    errors = []
    total = 0
    for file in ROOT.rglob("*.py"):
        if any(part.startswith(".") or part == "__pycache__" for part in file.relative_to(ROOT).parts):
            continue
        total += 1
        try:
            ast.parse(file.read_text(encoding="utf-8-sig"), filename=str(file))
        except (SyntaxError, UnicodeError) as exc:
            errors.append(f"{file.relative_to(ROOT)}: {exc}")
    print(f"Проверено Python-файлов: {total}; ошибок синтаксиса: {len(errors)}")
    for error in errors:
        print("[Ошибка]", error)
    missing = missing_requirements(ROOT / "requirements.txt")
    if missing:
        print("[Нужна установка]", ", ".join(missing))
        print("Команда: python -m pip install -r requirements.txt")
    else:
        print("[OK] Основные зависимости установлены")
    print("[Важно] Авторизацию Playerok и Telegram можно проверить только с действительными настройками и доступом к сети")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
