@echo off
setlocal
cd /d "%~dp0"
py -3.12 -c "import sys" >nul 2>nul
if not errorlevel 1 (
    py -3.12 bot.py
) else (
    python bot.py
)
echo.
echo Bot process finished.
pause
