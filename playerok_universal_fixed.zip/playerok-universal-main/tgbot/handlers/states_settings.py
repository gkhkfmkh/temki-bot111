import os
import traceback
from html import escape
from logging import getLogger
from aiogram import types, Router, Bot, F
from aiogram.fsm.context import FSMContext

from settings import Settings as sett
from core.configs import (
    MAX_IMPORT_SIZE,
    SUPPORTED_EXTENSIONS,
    safe_file_name,
    prepare_import_dir,
    clear_import_dir,
    clear_temp_dir,
    peek_import
)
from core.modules import (
    MODULE_EXTENSIONS,
    MAX_MODULE_SIZE,
    ModuleImportError,
    prepare_module_import_dir,
    clear_module_import_dir,
    stage_archive_modules,
    stage_single_py_module,
    install_staged_module
)

from .. import templates as templ
from .. import states
from .. import callback_datas as calls
from ..helpful import throw_float_message, show_module_checks

from utils import (
    is_cookies_valid,
    is_token_valid,
    is_user_agent_valid,
    is_proxy_valid,
    is_proxy_working,
    is_url_valid,
    is_custom_api_url_working,
    normalize_custom_api_url
)


logger = getLogger("universal.telegram")

router = Router()


@router.message(states.SettingsStates.waiting_for_cookies, F.text)
async def handler_waiting_for_cookies(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        str_cookies = message.text
        cookies = {
            c.split("=")[0].strip(): c.split("=")[1].strip() for c
            in str_cookies.split(";") if c.strip() and "=" in c
        }
        
        if not is_cookies_valid(str_cookies) or not is_token_valid(cookies["token"]):
            raise Exception("❌ Неверные Cookie-данные. Убедитесь, что они указаны в формате Header String")

        config = sett.get("config")
        config["playerok"]["api"]["cookies"] = str_cookies
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text("🍪 <b>Cookie-данные</b> успешно изменены"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="auth").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="auth").pack())
        )


@router.message(states.SettingsStates.waiting_for_user_agent, F.text)
async def handler_waiting_for_user_agent(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        user_agent = message.text
        
        if not is_user_agent_valid(user_agent):
            raise Exception("❌ Неверный формат User Agent. Пример: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36")

        config = sett.get("config")
        config["playerok"]["api"]["user_agent"] = user_agent
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(f"✅ <b>User Agent</b> был успешно изменён на <b>{user_agent}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="auth").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="auth").pack())
        )


@router.message(states.SettingsStates.waiting_for_pl_proxy, F.text)
async def handler_waiting_for_pl_proxy(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        proxy = message.text
        
        if len(proxy) <= 3:
            raise Exception("❌ Слишком короткое значение")
        if not is_proxy_valid(proxy):
            raise Exception("❌ Неверный формат прокси. Правильный формат: user:pass@ip:port или ip:port")
        if not is_proxy_working(proxy):
            raise Exception("❌ Указанный вами прокси не работает. Нет подключения к playerok.com")

        config = sett.get("config")
        config["playerok"]["api"]["proxy"] = proxy
        sett.set("config", config)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(f"✅ <b>Прокси для Playerok</b> был успешно изменён на <b>{proxy}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )


@router.message(states.SettingsStates.waiting_for_tg_proxy, F.text)
async def handler_waiting_for_tg_proxy(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        proxy = message.text
        
        if len(proxy) <= 3:
            raise Exception("❌ Слишком короткое значение")
        if not is_proxy_valid(proxy):
            raise Exception("❌ Неверный формат прокси. Правильный формат: user:pass@ip:port или ip:port")
        if not is_proxy_working(proxy, "https://api.telegram.org/"):
            raise Exception("❌ Указанный вами прокси не работает. Нет подключения к api.telegram.org")

        config = sett.get("config")
        config["telegram"]["api"]["proxy"] = proxy
        sett.set("config", config)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(f"✅ <b>Прокси для Telegram</b> был успешно изменён на <b>{proxy}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.auth_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )


@router.message(states.SettingsStates.waiting_for_tg_custom_api_url, F.text)
async def handler_waiting_for_tg_custom_api_url(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)

        cust_api_url = normalize_custom_api_url(message.text.strip())

        if not is_url_valid(cust_api_url):
            raise Exception("❌ Неверный формат URL. Пример: https://tg-proxy.ваш-поддомен.workers.dev")
        if not is_custom_api_url_working(cust_api_url):
            raise Exception("❌ По указанному URL Telegram API не отвечает. Убедитесь, что прокси развёрнут и работает")

        config = sett.get("config")
        config["telegram"]["api"]["custom_api_url"] = cust_api_url
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(
                f"✅ <b>Кастомный URL Telegram API</b> был успешно изменён на <b>{cust_api_url}</b>"
                f"\n\n❗ Изменения применятся после перезагрузки бота"
            ),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(e),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )


@router.message(states.SettingsStates.waiting_for_requests_timeout, F.text)
async def handler_waiting_for_requests_timeout(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        timeout = message.text
        
        if not timeout.isdigit():
            raise Exception("❌ Вы должны ввести числовое значение")       
        if int(timeout) < 0:
            raise Exception("❌ Слишком низкое значение")

        config = sett.get("config")
        config["playerok"]["api"]["requests_timeout"] = int(timeout)
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(f"✅ <b>Таймаут запросов</b> был успешно изменён на <b>{timeout}</b> сек."),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )


@router.message(states.SettingsStates.waiting_for_listener_requests_delay, F.text)
async def handler_waiting_for_listener_requests_delay(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        delay = message.text
        
        if not delay.isdigit():
            raise Exception("❌ Вы должны ввести числовое значение")
        if int(delay) < 0:
            raise Exception("❌ Слишком низкое значение")

        config = sett.get("config")
        config["playerok"]["api"]["listener_requests_delay"] = int(delay)
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(f"✅ <b>Периодичность запросов</b> была успешна изменена на <b>{delay}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.conn_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="conn").pack())
        )


@router.message(states.SettingsStates.waiting_for_notifications_chat_id, F.text)
async def handler_waiting_for_notifications_chat_id(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        chat_input = message.text
        
        if len(chat_input) < 0:
            raise Exception("❌ Слишком низкое значение")
        
        if chat_input.isdigit(): 
            chat_id = "-100" + str(chat_input).replace("-100", "")
        else: 
            chat_id = "@" + str(chat_input).replace("@", "")
        
        config = sett.get("config")
        config["playerok"]["notifications"]["chat_id"] = chat_id
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.notifications_float_text(f"✅ <b>Чат для уведомлений</b> был успешно изменён на <b>{chat_id}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="notifications").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.notifications_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="notifications").pack())
        )


@router.message(states.SettingsStates.waiting_for_auto_withdrawal_interval, F.text)
async def handler_waiting_for_auto_withdrawal_interval(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        interval = message.text
        
        if not interval.isdigit():
            raise Exception("❌ Вы должны ввести числовое значение")
        if int(interval) <= 1:
            raise Exception("❌ Слишком низкое значение")
        
        interval_int = int(interval)

        config = sett.get("config")
        config["playerok"]["auto_withdrawal"]["interval"] = interval_int
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_float_text(f"✅ <b>Интервал вывода</b> был успешно изменён на <b>{interval_int}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )


@router.message(states.SettingsStates.waiting_for_sbp_bank_phone_number, F.text)
async def handler_waiting_for_sbp_bank_phone_number(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        data = await state.get_data()
        sbp_bank_id = data.get("sbp_bank_id")
        
        phone_number = message.text
        
        if not phone_number.isdigit():
            raise Exception("❌ Вы указали некорректный номер телефона")
        if len(phone_number) < 4:
            raise Exception("❌ Слишком короткое значение")
        
        if phone_number.startswith("8"):
            phone_number = phone_number.replace("8", "+7", 1)

        config = sett.get("config")
        config["playerok"]["auto_withdrawal"]["credentials_type"] = "sbp"
        config["playerok"]["auto_withdrawal"]["sbp_bank_id"] = sbp_bank_id
        config["playerok"]["auto_withdrawal"]["sbp_phone_number"] = phone_number.strip()
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_sbp_float_text(f"✅ <b>Данные вывода</b> были успешно изменены на <b>{phone_number} (СБП)</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_sbp_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )


@router.message(states.SettingsStates.waiting_for_usdt_address, F.text)
async def handler_waiting_for_usdt_address(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        address = message.text
        
        if len(address) <= 10:
            raise Exception("❌ Слишком короткое значение")

        config = sett.get("config")
        config["playerok"]["auto_withdrawal"]["credentials_type"] = "usdt"
        config["playerok"]["auto_withdrawal"]["usdt_address"] = address
        sett.set("config", config)

        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_float_text(f"✅ <b>Данные вывода</b> были успешно изменены на <b>{address} (USDT TRC20)</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.withdrawal_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="withdrawal").pack())
        )
            

@router.message(states.SettingsStates.waiting_for_watermark_value, F.text)
async def handler_waiting_for_watermark_value(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        watermark = message.text

        if len(watermark) <= 0 or len(watermark) >= 150:
            raise Exception("❌ Слишком короткое или длинное значение")

        config = sett.get("config")
        config["playerok"]["watermark"]["value"] = watermark
        sett.set("config", config)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.other_float_text(f"✅ <b>Водяной знак сообщений</b> был успешно изменён на <b>{watermark}</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="other").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.other_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="other").pack())
        )
            

@router.message(states.SettingsStates.waiting_for_logs_max_file_size, F.text)
async def handler_waiting_for_logs_max_file_size(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        
        max_size = message.text
        
        if not max_size.isdigit():
            raise Exception("❌ Вы должны ввести числовое значение")
        if int(max_size) <= 0:
            raise Exception("❌ Слишком низкое значение")
        
        max_size_int = int(max_size)

        config = sett.get("config")
        config["logs"]["max_file_size"] = max_size_int
        sett.set("config", config)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.logs_float_text(f"✅ <b>Максимальный размер файла логов</b> был успешно изменён на <b>{max_size_int} MB</b>"),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="logs").pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.logs_float_text(e), 
            reply_markup=templ.back_kb(calls.MenuNavigation(to="logs").pack())
        )
            

@router.message(states.SettingsStates.waiting_for_new_fast_reply_text, F.text)
async def handler_waiting_for_new_fast_reply_text(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        text = message.text

        data = await state.get_data()
        last_page = data.get("last_page", 0)

        fast_replies = sett.get("fast_replies")
        fast_replies.append(text)
        sett.set("fast_replies", fast_replies)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.new_fast_reply_text(f"✅ <b>Быстрый ответ</b> успешно добавлен: <blockquote>{text}</blockquote>"),
            reply_markup=templ.back_kb(calls.FastRepliesPagination(page=last_page).pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.new_fast_reply_text(e), 
            reply_markup=templ.back_kb(calls.FastRepliesPagination(page=last_page).pack())
        )
            

@router.message(states.SettingsStates.waiting_for_fast_reply_text, F.text)
async def handler_waiting_for_fast_reply_text(message: types.Message, state: FSMContext):
    try:
        await state.set_state(None)
        text = message.text

        data = await state.get_data()
        index = data.get("fast_reply_index")
        last_page = data.get("last_page", 0)

        fast_replies = sett.get("fast_replies")
        fast_replies[index] = text
        sett.set("fast_replies", fast_replies)
        
        await throw_float_message(
            state=state,
            message=message,
            text=templ.new_fast_reply_text(f"✅ <b>Текст авто-ответ</b> был успешно изменён на: <blockquote>{text}</blockquote>"),
            reply_markup=templ.back_kb(calls.FastRepliesPagination(page=last_page).pack())
        )
    except Exception as e:
        await throw_float_message(
            state=state,
            message=message,
            text=templ.new_fast_reply_text(e), 
            reply_markup=templ.back_kb(calls.FastRepliesPagination(page=last_page).pack())
        )


@router.message(states.SettingsStates.waiting_for_module_file, F.document)
async def handler_waiting_for_module_file(message: types.Message, state: FSMContext, bot: Bot):
    user_id = message.from_user.id
    data = await state.get_data()
    last_page = data.get("last_page", 0)

    try:
        await state.set_state(None)
        await state.update_data(import_pending=None)

        file_name = safe_file_name(message.document.file_name)
        is_py = file_name.lower().endswith(".py")
        if not is_py and not file_name.lower().endswith(MODULE_EXTENSIONS):
            raise ModuleImportError("❌ Нужен архив <b>.zip</b> / <b>.rar</b> или одиночный файл <b>.py</b>")
        if (message.document.file_size or 0) > MAX_MODULE_SIZE:
            raise ModuleImportError(f"❌ Файл слишком большой (максимум {MAX_MODULE_SIZE // 1024 // 1024} МБ)")

        user_dir = prepare_module_import_dir(user_id)
        src_path = os.path.join(user_dir, file_name)
        await bot.download(message.document, destination=src_path)

        stage = os.path.join(user_dir, "_stage")
        if is_py:
            mods = stage_single_py_module(src_path, stage)
        else:
            mods = stage_archive_modules(src_path, stage)

        collided = [m for m in mods if m["exists"]]
        fresh = [m for m in mods if not m["exists"]]

        if not collided:
            installed = [install_staged_module(m, "replace") for m in mods]
            if len(installed) == 1:
                result = f"✅ Модуль <b>успешно импортирован</b>: <code>{file_name}</code>"
            else:
                str_installed = "\n".join(f"・ <b>{name}</b>" for name in installed)
                result = (
                    f"✅ Успешно импортировано <b>{len(installed)} модулей</b> из <code>{file_name}</code>:"
                    f"\n\n<blockquote>{str_installed}</blockquote>"
                )
            clear_module_import_dir(user_id)
            clear_temp_dir()
            await show_module_checks(message, state, result, installed, calls.ModulesPagination(page=last_page).pack())
            return

        fresh_installed = [install_staged_module(m, "replace") for m in fresh]
        await state.update_data(import_pending={
            "collided": [{"name": m["name"], "source": m["source"], "is_py": m["is_py"]} for m in collided],
            "fresh_installed": fresh_installed,
            "last_page": last_page,
        })
        await throw_float_message(
            state=state,
            message=message,
            text=templ.module_exists_warning_text(
                [m["name"] for m in collided],
                fresh_names=fresh_installed or None
            ),
            reply_markup=templ.module_import_actions_kb()
        )
    except Exception as e:
        if not isinstance(e, ModuleImportError):
            logger.error(f"Не удалось импортировать модуль: {traceback.format_exc()}")
        text = str(e) if isinstance(e, ModuleImportError) else (
            f"❌ Не удалось импортировать модуль: <blockquote>{escape(str(e))}</blockquote>"
        )

        await throw_float_message(
            state=state,
            message=message,
            text=templ.modules_float_text(text),
            reply_markup=templ.back_kb(calls.ModulesPagination(page=last_page).pack())
        )
        await state.update_data(import_pending=None)
        clear_module_import_dir(user_id)
        clear_temp_dir()


@router.message(states.SettingsStates.waiting_for_module_file)
async def handler_waiting_for_module_file_wrong(message: types.Message, state: FSMContext):
    data = await state.get_data()
    last_page = data.get("last_page", 0)

    await throw_float_message(
        state=state,
        message=message,
        text=templ.modules_float_text("❌ Нужен архив <b>.zip</b> / <b>.rar</b> или одиночный файл <b>.py</b>"),
        reply_markup=templ.back_kb(calls.ModulesPagination(page=last_page).pack())
    )


@router.message(states.SettingsStates.waiting_for_config_file, F.document)
async def handler_waiting_for_config_file(message: types.Message, state: FSMContext, bot: Bot):
    from ..callback_handlers.actions_configs import apply_import

    user_id = message.from_user.id
    try:
        await state.set_state(None)

        file_name = safe_file_name(message.document.file_name)
        if not file_name.lower().endswith(SUPPORTED_EXTENSIONS):
            raise Exception("❌ Нужен файл в формате <b>.json</b> или архив <b>.zip</b> / <b>.rar</b>")
        if (message.document.file_size or 0) > MAX_IMPORT_SIZE:
            raise Exception(f"❌ Файл слишком большой (максимум {MAX_IMPORT_SIZE // 1024 // 1024} МБ)")

        import_path = os.path.join(prepare_import_dir(user_id), file_name)
        await bot.download(message.document, destination=import_path)
        await state.update_data(import_config_path=import_path)

        if "config" in peek_import(import_path):
            return await throw_float_message(
                state=state,
                message=message,
                text=templ.configs_float_text(
                    "📥 Файл принят. Что делать с <b>Cookie-данными, токеном Telegram бота и ключ-паролем</b>?"
                    "\n\n<blockquote><b>(?)</b> Список авторизованных пользователей останется вашим в любом случае, "
                    "чтобы вы не потеряли доступ к боту.</blockquote>"
                ),
                reply_markup=templ.configs_secrets_kb()
            )

        return await apply_import(state, message, user_id, keep_secrets=True)
    except Exception as e:
        clear_import_dir(user_id)
        await state.update_data(import_config_path=None)
        await throw_float_message(
            state=state,
            message=message,
            text=templ.configs_float_text(e),
            reply_markup=templ.back_kb(calls.MenuNavigation(to="configs").pack())
        )