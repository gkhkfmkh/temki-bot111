import math
import textwrap
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from settings import Settings as sett

from .. import callback_datas as calls


def comms_text():
    custom_commands = sett.get("custom_commands")
    txt = textwrap.dedent(f"""
        <b>❗ Команды</b>
        Всего <b>{len(custom_commands)}</b> команд:
    """)
    return txt


def comms_kb(page=0):
    custom_commands = sett.get("custom_commands")
    
    rows = []
    items_per_page = 10
    total_pages = math.ceil(len(custom_commands.keys())/items_per_page)
    total_pages = total_pages if total_pages > 0 else 1

    if page < 0: page = 0
    elif page >= total_pages: page = total_pages-1

    start_offset = page * items_per_page
    end_offset = start_offset + items_per_page

    for command in list(custom_commands.keys())[start_offset:end_offset]:
        command_text = "\n".join(custom_commands[command])
        rows.append([InlineKeyboardButton(text=f'{command} → {command_text}', callback_data=calls.CustomCommandPage(command=command).pack())])
        

    if total_pages > 1:
        buttons_row = []
        btn_back = InlineKeyboardButton(text="←", callback_data=calls.CustomCommandsPagination(page=page-1).pack()) if page > 0 else InlineKeyboardButton(text="🛑",callback_data="null_answer")
        buttons_row.append(btn_back)
            
        btn_pages = InlineKeyboardButton(text=f"📃 {page+1}/{total_pages}",callback_data=calls.PageEnter(to="custom_commands", page=page, total=total_pages).pack())
        buttons_row.append(btn_pages)
        
        btn_next = InlineKeyboardButton(text="→", callback_data=calls.CustomCommandsPagination(page=page+1).pack()) if page < total_pages -1 else InlineKeyboardButton(text="🛑", callback_data="null_answer")
        buttons_row.append(btn_next)
        rows.append(buttons_row)

    rows.append([
        InlineKeyboardButton(text="➕ Добавить",callback_data="enter_new_custom_command"),
        InlineKeyboardButton(text="🏷️ Заменители",callback_data=calls.PlaceholdersNavigation(to="account", by="comms").pack())
    ])
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=calls.MenuNavigation(to="default").pack())])
    
    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    return kb


def comms_float_text(placeholder: str):
    txt = textwrap.dedent(f"""
        <b>❗ Команды</b>
        \n{placeholder}
    """)
    return txt


def new_comm_float_text(placeholder: str):
    txt = textwrap.dedent(f"""
        <b>➕❗ Добавление команды</b>
        \n{placeholder}
    """)
    return txt