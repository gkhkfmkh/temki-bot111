import math
import textwrap
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from core.modules import get_modules

from .. import callback_datas as calls

                    
def modules_text():
    modules = get_modules()
    txt = textwrap.dedent(f"""
        <b>🔌 Модули</b>
        Всего <b>{len(modules)}</b> подключенных модулей:
    """)
    return txt


def modules_kb(page=0):
    modules = get_modules()
    
    rows = []
    items_per_page = 10
    total_pages = math.ceil(len(modules) / items_per_page)
    total_pages = total_pages if total_pages > 0 else 1

    if page < 0: page = 0
    elif page >= total_pages: page = total_pages - 1

    start_offset = page * items_per_page
    end_offset = start_offset + items_per_page

    for module in list(modules)[start_offset:end_offset]:
        rows.append([InlineKeyboardButton(text=module.meta.name, callback_data=calls.ModulePage(uuid=module.uuid).pack())])

    if total_pages > 1:
        buttons_row = []
        btn_back = InlineKeyboardButton(text="←", callback_data=calls.ModulesPagination(page=page - 1).pack()) if page > 0 else InlineKeyboardButton(text="🛑", callback_data="null_answer")
        buttons_row.append(btn_back)

        btn_pages = InlineKeyboardButton(text=f"📃 {page+1}/{total_pages}", callback_data=calls.PageEnter(to="modules", page=page, total=total_pages).pack())
        buttons_row.append(btn_pages)

        btn_next = InlineKeyboardButton(text="→", callback_data=calls.ModulesPagination(page=page+1).pack()) if page < total_pages - 1 else InlineKeyboardButton(text="🛑", callback_data="null_answer")
        buttons_row.append(btn_next)
        rows.append(buttons_row)
        
    rows.append([InlineKeyboardButton(text="➕ Импортировать", callback_data="send_module_file")])
    rows.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=calls.MenuNavigation(to="default").pack())])

    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    return kb


def modules_float_text(placeholder):
    return f"<b>🔌 Модули</b>\n\n{placeholder}"


def module_exists_warning_text(collided_names, fresh_names=None):
    names = "\n".join(f"・ <b>{n}</b>" for n in collided_names)
    extra = ""
    if fresh_names:
        installed = ", ".join(f"<b>{n}</b>" for n in fresh_names)
        extra = f"\n\n✅ Новые модули из архива уже установлены: {installed}"
    return modules_float_text(
        f"⚠️ Такие модули <b>уже установлены</b>:"
        f"\n<blockquote>{names}</blockquote>"
        f"{extra}"
        f"\n\nЧто сделать?"
        f"\n\n🔀 <b>Слияние</b> — обновить код, настройки и данные <b>сохранятся</b>"
        f"\n♻️ <b>Замена</b> — поставить заново, данные <b>удалятся</b>"
        f"\n➕ <b>Отдельным модулем</b> — копия рядом с оригиналом (обе будут активны — не включайте обе сразу)"
    )


def module_import_actions_kb():
    rows = [
        [InlineKeyboardButton(text="🔀 Слияние (данные сохранятся)", callback_data="modimp_merge")],
        [InlineKeyboardButton(text="♻️ Замена (данные удалятся)", callback_data="modimp_replace")],
        [InlineKeyboardButton(text="➕ Отдельным модулем", callback_data="modimp_duplicate")],
        [InlineKeyboardButton(text="✖️ Отмена", callback_data="modimp_cancel")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)