import os
import json
import copy
import time
import shutil
import tempfile
from dataclasses import dataclass


@dataclass
class SettingsFile:
    name: str
    path: str
    need_restore: bool
    default: list | dict


CONFIG = SettingsFile(
    name="config",
    path="bot_settings/config.json",
    need_restore=True,
    default={
        "playerok": {
            "api": {
                "cookies": "",
                "user_agent": "",
                "proxy": "",
                "requests_timeout": 30
            },
            "watermark": {
                "enabled": True,
                "value": "©️ 𝗣𝗹𝗮𝘆𝗲𝗿𝗼𝗸 𝗨𝗻𝗶𝘃𝗲𝗿𝘀𝗮𝗹"
            },
            "read_chat": True,
            "auto_restore_items": {
                "sold": True,
                "expired": False,
                "all": True,
                "free": True,
                "premium": True,
                "publish_status": "last",
                "recreate": False
            },
            "auto_complete_deals": {
                "enabled": False,
                "all": True
            },
            "blacklist": {
                "auto_refund": False
            },
            "auto_bump_items": {
                "enabled": False,
                "mode": "interval",
                "interval": 3600,
                "position": 10,
                "cooldown": 600,
                "check_interval": 120,
                "all": False,
                "last_time": "",
                "last_check_time": "",
                "night": {
                    "enabled": False,
                    "interval": 14400,
                    "position": 25,
                    "time_from": "23:00",
                    "time_to": "08:00"
                }
            },
            "auto_withdrawal": {
                "enabled": False,
                "interval": 86400,
                "last_time": "",
                "credentials_type": "",
                "card_id": "",
                "sbp_bank_id": "",
                "sbp_phone_number": "",
                "usdt_address": ""
            },
            "notifications": {
                "enabled": True,
                "chat_id": "",
                "events": {
                    "new_user_message": True,
                    "new_system_message": True,
                    "new_deal": True,
                    "new_review": True,
                    "new_problem": True,
                    "deal_status_changed": True,
                    "item_restored": True,
                    "item_bumped": True,
                    "withdrawal_requested": True
                }
            },
        },
        "telegram": {
            "api": {
                "token": "",
                "proxy": "",
                "custom_api_url": ""
            },
            "bot": {
                "password": "",
                "signed_users": []
            }
        },
        "updates": {
            "auto_update": True,
            "notify": True
        },
        "logs": {
            "max_file_size": 512
        }
    }
)
MESSAGES = SettingsFile(
    name="messages",
    path="bot_settings/messages.json",
    need_restore=True,
    default={
        "first_message": {
            "label": "👋 Приветствие",
            "enabled": True,
            "text": [
                "👋 Привет, {user.username}, я бот-помощник 𝗣𝗹𝗮𝘆𝗲𝗿𝗼𝗸 𝗨𝗻𝗶𝘃𝗲𝗿𝘀𝗮𝗹",
                "",
                "💡 Если вы хотите поговорить с продавцом, напишите команду !продавец, чтобы я пригласил его в этот диалог"
            ]
        },
        "cmd_error": {
            "label": "❌ Ошибка команды",
            "enabled": True,
            "text": [
                "❌ При вводе команды произошла ошибка: {error}"
            ]
        },
        "cmd_seller": {
            "label": "💬 Вызов продавца",
            "enabled": True,
            "text": [
                "💬 Продавец был вызван в этот чат. Ожидайте, пока он подключится к диалогу..."
            ]
        },
        "new_deal": {
            "label": "📋 Новая сделка",
            "enabled": False,
            "text": [
                "📋 Спасибо за покупку «{item.name}» за {item.price}₽",
                ""
                "Меня сейчас может не быть на месте, чтобы позвать его, используйте команду !продавец"
            ]
        },
        "deal_sent": {
            "label": "✅ Товар отправлен",
            "enabled": False,
            "text": [
                "✅ Я подтвердил выполнение вашего заказа! Если вы не получили купленный товар - напишите это в чате"
            ]
        },
        "deal_confirmed": {
            "label": "🌟 Сделка подтверждена",
            "enabled": False,
            "text": [
                "🌟 Спасибо за успешную сделку. Буду рад, если оставите отзыв. Жду вас в своём магазине в следующий раз, удачи!"
            ]
        },
        "deal_refunded": {
            "label": "📦 Возврат сделки",
            "enabled": False,
            "text": [
                "📦 Заказ был возвращён. Надеюсь, эта сделка не принесла вам неудобств. Жду вас в своём магазине в следующий раз, удачи!"
            ]
        },
        "deal_has_problem": {
            "label": "🙏 Проблема в сделке",
            "enabled": False,
            "text": [
                "🙏 Пожалуйста, напишите, с чем у вас возникли проблемы, чтобы я смог вам помочь.",
                "",
                "❗ Если меня нет в сети, позовите командой !продавец"
            ]
        },
        "new_review": {
            "label": "✨ Спасибо за отзыв",
            "enabled": False,
            "text": [
                "✨ Спасибо за {review_rating}⭐ отзыв! Надеюсь, вам понравилось качество выполненной работы"
            ]
        },
        "blacklist_deal_refunded": {
            "label": "🚫 Возврат сделки из ЧС",
            "enabled": True,
            "text": [
                "🚫 Вы находитесь в чёрном списке продавца, поэтому сделка была возвращена"
            ]
        }
    }
)
CUSTOM_COMMANDS = SettingsFile(
    name="custom_commands",
    path="bot_settings/custom_commands.json",
    need_restore=False,
    default={}
)
AUTO_DELIVERIES = SettingsFile(
    name="auto_deliveries",
    path="bot_settings/auto_deliveries.json",
    need_restore=False,
    default=[]
)
AUTO_RESTORE_ITEMS = SettingsFile(
    name="auto_restore_items",
    path="bot_settings/auto_restore_items.json",
    need_restore=False,
    default={
        "included": [],
        "excluded": []
    }
)
AUTO_COMPLETE_DEALS = SettingsFile(
    name="auto_complete_deals",
    path="bot_settings/auto_complete_deals.json",
    need_restore=False,
    default={
        "included": [],
        "excluded": []
    }
)
AUTO_BUMP_ITEMS = SettingsFile(
    name="auto_bump_items",
    path="bot_settings/auto_bump_items.json",
    need_restore=False,
    default={
        "included": [],
        "excluded": []
    }
)
FAST_REPLIES = SettingsFile(
    name="fast_replies",
    path="bot_settings/fast_replies.json",
    need_restore=False,
    default=[]
)
DATA_REPLACEMENT = SettingsFile(
    name="data_replacement",
    path="bot_settings/data_replacement.json",
    need_restore=False,
    default=[]
)
BLACKLIST = SettingsFile(
    name="blacklist",
    path="bot_settings/blacklist.json",
    need_restore=True,
    default={
        "users": {}
    }
)
DATA = [CONFIG, MESSAGES, CUSTOM_COMMANDS, AUTO_DELIVERIES, AUTO_RESTORE_ITEMS, AUTO_COMPLETE_DEALS, AUTO_BUMP_ITEMS, FAST_REPLIES, DATA_REPLACEMENT, BLACKLIST]


def validate_config(config, default):
    """
    Проверяет структуру конфига на соответствие стандартному шаблону.

    :param config: Текущий конфиг.
    :type config: `dict`

    :param default: Стандартный шаблон конфига.
    :type default: `dict`

    :return: True если структура валидна, иначе False.
    :rtype: bool
    """
    
    for key, value in default.items():
        if key not in config:
            return False
        if type(config[key]) is not type(value):
            return False
        if isinstance(value, dict) and isinstance(config[key], dict):
            if not validate_config(config[key], value):
                return False
    return True


def restore_config(config: dict, default: dict):
    """
    Восстанавливает недостающие параметры в конфиге из стандартного шаблона.
    И удаляет параметры из конфига, которых нету в стандартном шаблоне.

    :param config: Текущий конфиг.
    :type config: `dict`

    :param default: Стандартный шаблон конфига.
    :type default: `dict`

    :return: Восстановленный конфиг.
    :rtype: `dict`
    """
    config = copy.deepcopy(config)

    def check_default(config, default):
        for key, value in dict(default).items():
            if key not in config:
                config[key] = copy.deepcopy(value)
            elif type(value) is not type(config[key]):
                config[key] = copy.deepcopy(value)
            elif isinstance(value, dict) and isinstance(config[key], dict):
                check_default(config[key], value)
        return config

    config = check_default(config, default)
    return config
    

def get_json(path: str, default: dict, need_restore: bool = True) -> dict:
    """
    Получает данные файла настроек.
    Создаёт файл настроек, если его нет.
    Добавляет новые данные, если такие есть.

    :param path: Путь к json файлу.
    :type path: `str`

    :param default: Стандартный шаблон файла.
    :type default: `dict`

    :param need_restore: Нужно ли сделать проверку на целостность конфига.
    :type need_restore: `bool`
    """
    
    folder_path = os.path.dirname(path)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    config = None
    for _ in range(3):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            if need_restore:
                new_config = restore_config(config, default)
                if config != new_config:
                    config = new_config
                    with open(path, 'w', encoding='utf-8') as f:
                        json.dump(config, f, indent=4, ensure_ascii=False)
            return config
        except FileNotFoundError:
            break
        except (PermissionError, BlockingIOError):
            # файл как раз подменяют атомарной записью (Windows) — читаем ещё раз, а не затираем
            time.sleep(0.1)
        except:
            break

    if os.path.exists(path):
        try: shutil.copyfile(path, f"{path}.bak")
        except: pass
    config = copy.deepcopy(default)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
    except:
        pass
    return config
    

def set_json(path: str, new: dict):
    """
    Устанавливает новые данные в файл настроек.

    :param path: Путь к json файлу.
    :type path: `str`

    :param new: Новые данные.
    :type new: `dict`
    """
    dir_name = os.path.dirname(path)
    
    with tempfile.NamedTemporaryFile( # атомарная запись файла
        "w",
        encoding="utf-8",
        dir=dir_name,
        delete=False
    ) as tmp:
        json.dump(new, tmp, ensure_ascii=False, indent=4)
        tmp.flush()
        os.fsync(tmp.fileno())

    os.replace(tmp.name, path)


class Settings:
    
    @staticmethod
    def get(name: str, data: list[SettingsFile] = DATA) -> dict | list | None:
        try: 
            file = [file for file in data if file.name == name][0]
            return get_json(file.path, file.default, file.need_restore)
        except: return None

    @staticmethod
    def set(name: str, new: list | dict, data: list[SettingsFile] = DATA):
        try: 
            file = [file for file in data if file.name == name][0]
            set_json(file.path, new)
        except: pass

    @staticmethod
    def get_message_label(message_id: str) -> str:
        return MESSAGES.default.get(message_id, {}).get("label") or message_id