"""Первичная установка зависимостей ДО импорта aiogram, curl_cffi и ядра.

Вызывается в самом начале bot.py. Не затрагивает пользовательские настройки.
"""
from __future__ import annotations

import importlib.metadata
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def missing_requirements(path: Path) -> list[str]:
    """Проверяет установленные дистрибутивы и версии, с учётом платформы."""
    try:
        from packaging.requirements import Requirement
    except ImportError:
        # packaging идёт с pip не на каждой системе. Установку сделает pip.
        return ["packaging (библиотека проверки зависимостей)"]

    missing = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        raw = raw.strip()
        if not raw or raw.startswith("#") or raw.startswith("-"):
            continue
        req = Requirement(raw)
        if req.marker and not req.marker.evaluate():
            continue
        try:
            installed = importlib.metadata.version(req.name)
            if installed not in req.specifier:
                missing.append(f"{req.name} ({installed}, требуется {req.specifier})")
        except importlib.metadata.PackageNotFoundError:
            missing.append(req.name)
    return missing


def ensure_requirements() -> None:
    path = ROOT / "requirements.txt"
    missing = missing_requirements(path)
    if not missing:
        return
    print("[Установка] Отсутствуют или несовместимы: " + ", ".join(missing), flush=True)
    print("[Установка] Выполняю python -m pip install -r requirements.txt", flush=True)
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(path)])
    except (OSError, subprocess.CalledProcessError) as exc:
        raise SystemExit(
            "Не удалось установить зависимости. Убедитесь, что установлен Python 3.12 "
            "и есть интернет. Попробуйте: python -m pip install -r requirements.txt"
        ) from exc
    # При запуске в одном процессе зависимости должны быть доступны в sys.path.
    import importlib
    importlib.invalidate_caches()
