@echo off
setlocal
cd /d "%~dp0"
py -3.12 -c "import sys" >nul 2>nul
if not errorlevel 1 (
    py -3.12 -m pip install -r requirements.txt
) else (
    python -m pip install -r requirements.txt
)
pause
